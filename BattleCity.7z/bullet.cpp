#include "bullet.h"

Bullet::Bullet()
{
}
