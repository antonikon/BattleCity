#include "tank.h"

Tank::Tank()
{
}
